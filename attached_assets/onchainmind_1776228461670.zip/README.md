# OnchainMind 🚀

AI memory layer for Web3 + GameFi using Zilliz Cloud.

## Setup

### 1. Install deps
npm install

### 2. Setup env
Copy `.env.example` → `.env`

Fill:
- ZILLIZ_ADDRESS (your cluster endpoint)
- ZILLIZ_TOKEN (API key)
- OPENAI_API_KEY

### 3. Run server
npm run dev

## API

### Insert memory
POST /memory/insert
```json
{ "text": "Player helped NPC" }
```

### Search memory
POST /memory/search
```json
{ "text": "who helped NPC?" }
```

## Core Stack
- Zilliz Cloud (Vector DB)
- OpenAI Embeddings
- Node.js Express
