import { MilvusClient } from "@zilliz/milvus2-sdk-node";
import OpenAI from "openai";
import dotenv from "dotenv";

dotenv.config();

const client = new MilvusClient({
  address: process.env.ZILLIZ_ADDRESS,
  token: process.env.ZILLIZ_TOKEN,
});

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

async function embed(text) {
  const res = await openai.embeddings.create({
    model: "text-embedding-3-small",
    input: text
  });
  return res.data[0].embedding;
}

export async function insertMemory(text) {
  const vector = await embed(text);

  return await client.insert({
    collection_name: "npc_memory",
    fields_data: [
      {
        embedding: vector,
        text
      }
    ]
  });
}

export async function searchMemory(text) {
  const vector = await embed(text);

  return await client.search({
    collection_name: "npc_memory",
    vector,
    limit: 5
  });
}
