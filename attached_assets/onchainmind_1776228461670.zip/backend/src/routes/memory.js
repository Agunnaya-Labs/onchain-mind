// optional expansion point for future auth/game logic
