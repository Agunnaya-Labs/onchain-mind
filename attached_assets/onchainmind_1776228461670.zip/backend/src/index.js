import express from "express";
import dotenv from "dotenv";
import { insertMemory, searchMemory } from "./zilliz.js";

dotenv.config();

const app = express();
app.use(express.json());

app.get("/", (req, res) => {
  res.send("OnchainMind API running");
});

app.post("/memory/insert", async (req, res) => {
  const result = await insertMemory(req.body.text);
  res.json(result);
});

app.post("/memory/search", async (req, res) => {
  const result = await searchMemory(req.body.text);
  res.json(result);
});

app.listen(process.env.PORT || 3000, () => {
  console.log("Server running");
});
